package com.virlabs.demo_flx_application.config;

/**
 * Created by Tamim on 28/09/2017.
 */



public class Global {
    public static final String API_URL = "https://webflix.virmana.com/api/";
    public static final String SECURE_KEY = "4F5A9C3D9A86FA54EACEDDD635185";

    public static final String Youtube_Key = "AIzaSyAephi0fVTEBXgphX7Z_WVSW8iPusDibtg"; // get it from this link  https://console.developers.google.com/apis/credentials

    public static final String ITEM_PURCHASE_CODE = "d506abfd-9fe2-4b71-b979-feff21bcad13";



    public static final String SUBSCRIPTION_ID = "com.virlabs.demo_flx_application.subs";

}



